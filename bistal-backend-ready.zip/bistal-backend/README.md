# Bistal Backend — Setup & Deployment Guide
# Written by Adedayo Digital Services

## 📁 PROJECT STRUCTURE
```
bistal-backend/
├── server.js           ← Main entry point
├── .env.example        ← Copy to .env and fill in
├── package.json
├── models/
│   ├── User.js         ← Customer accounts
│   ├── Product.js      ← Products/inventory
│   └── Order.js        ← Orders
├── routes/
│   ├── auth.js         ← Login, register, wishlist
│   ├── products.js     ← Product CRUD
│   └── orders.js       ← Order management
├── middleware/
│   └── auth.js         ← JWT protection
└── public/
    └── index.html      ← Put your frontend HTML here
```

---

## ⚡ STEP 1 — Get MongoDB (Free)

1. Go to https://cloud.mongodb.com
2. Sign up free → Create a project → Create a FREE cluster (M0)
3. Click "Connect" → "Connect your application"
4. Copy the connection string — looks like:
   mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/bistal

---

## ⚡ STEP 2 — Configure Environment

1. Copy `.env.example` to `.env`:
   cp .env.example .env

2. Open `.env` and fill in:
   - MONGODB_URI=your_connection_string_from_step_1
   - JWT_SECRET=any_long_random_string (e.g. bistal_tobi_2025_xk92ms)
   - ADMIN_PASSWORD=bistal2025 (change this!)

---

## ⚡ STEP 3 — Install & Run Locally

```bash
npm install
node server.js
```

You should see:
  ✅ MongoDB connected
  🚀 Bistal API running on port 5000

Test it: open http://localhost:5000/api/health

---

## ⚡ STEP 4 — Connect Your Frontend

In your bistal-premium.html, find this line near the top of the script:
  const API = 'http://localhost:5000/api';

Change it to your live URL when deployed, e.g.:
  const API = 'https://bistal-api.onrender.com/api';

---

## 🚀 DEPLOYMENT OPTIONS

### Option A — Render.com (FREE, recommended)
1. Push code to GitHub (free account)
2. Go to https://render.com → New → Web Service
3. Connect your GitHub repo
4. Set Environment Variables (same as .env)
5. Start command: node server.js
6. Done! Free URL given automatically

### Option B — Railway.app (~$5/month)
1. Go to https://railway.app
2. New Project → Deploy from GitHub
3. Add environment variables
4. Done in 2 minutes

### Option C — VPS (DigitalOcean/Contabo ~₦10,000–15,000/month)
- Full control, best for production
- Use PM2: npm install -g pm2 && pm2 start server.js

---

## 🔌 API ENDPOINTS REFERENCE

### AUTH
POST   /api/auth/register       → Create account
POST   /api/auth/login          → Login (returns JWT token)
GET    /api/auth/me             → Get current user (needs token)
PATCH  /api/auth/profile        → Update profile
POST   /api/auth/wishlist/:id   → Toggle wishlist item
POST   /api/auth/admin-login    → Admin password login

### PRODUCTS
GET    /api/products            → List all (supports ?featured=true&flash=true&search=&sort=)
GET    /api/products/:id        → Single product
POST   /api/products            → Create (admin only)
PATCH  /api/products/:id        → Update (admin only)
DELETE /api/products/:id        → Delete (admin only)
POST   /api/products/seed/defaults → Seed sample products (admin only)

### ORDERS
POST   /api/orders              → Place order (login required)
GET    /api/orders/my           → My orders (login required)
GET    /api/orders/track/:id    → Track by order ID (public)
GET    /api/orders              → All orders (admin only)
PATCH  /api/orders/:id/status   → Update status (admin only)
GET    /api/orders/admin/stats  → Dashboard stats (admin only)

---

## 💡 HOW TO USE JWT TOKEN (Frontend)

After login, save the token:
  localStorage.setItem('bistal_token', response.token);

Send it with every protected request:
  headers: { 'Authorization': 'Bearer ' + localStorage.getItem('bistal_token') }

---

## 📞 SUPPORT
Built by Adedayo Digital Services
WhatsApp: +234 808 494 2859
